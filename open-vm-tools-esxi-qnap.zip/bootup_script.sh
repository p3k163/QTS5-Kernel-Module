/bin/sleep 60
while [ ! -f /var/run/vmtoolsd.pid ]
do
  /etc/init.d/open-vm-tools start
  /bin/sleep 2
done
